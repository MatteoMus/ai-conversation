from __future__ import annotations

from .cli import cli_detect

if __name__ == "__main__":
    cli_detect()
